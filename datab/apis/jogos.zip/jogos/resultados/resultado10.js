[
{"result": "https://telegra.ph/file/69fc9aa5db44e1a742e81.jpg"}
]