[
{"result": "https://telegra.ph/file/2f6487964a5bf3942f06f.jpg"}
]