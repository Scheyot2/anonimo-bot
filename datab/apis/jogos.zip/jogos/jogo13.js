[
{"result": "https://telegra.ph/file/1e7f13201d632fecfe4db.jpg"}
]