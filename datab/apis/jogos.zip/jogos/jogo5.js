[
{"result": "https://telegra.ph/file/cf169aa1f5353e5aab50a.jpg"}
]